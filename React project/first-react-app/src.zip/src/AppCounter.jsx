import Counter from "./components/Counter"
import ToDo from "./components/ToDo"

function AppCounter(){
    
    return(
    <>
    <ToDo/>
    </>
    )  
}
export default AppCounter