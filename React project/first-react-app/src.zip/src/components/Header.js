function Header(){

    return <>
    <h1>This is my header</h1>

    </>
}

export default Header;