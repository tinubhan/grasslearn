function Footer(){

    return <>
    <h1>This is my footer</h1>

    </>
}

export default Footer;